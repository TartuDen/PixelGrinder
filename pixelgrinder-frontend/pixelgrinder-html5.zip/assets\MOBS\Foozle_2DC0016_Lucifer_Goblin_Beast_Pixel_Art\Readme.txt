
			------------------------------	
	
	Lucifer Goblin Beast Boss (1.0)

	Commissioned from: Baldur (https://twitter.com/the__baldur)
	Distributed by Foozle (www.foozle.io)

			------------------------------

	License: (Creative Commons Zero, CC0)
	http://creativecommons.org/publicdomain/zero/1.0/

	This content is free to use and modify for all projects, including commercial projects.
	Attribution not required.  If you would like to support, consider a voluntary donation.

			------------------------------

	Donate:   https://foozlecc.itch.io/
	Patreon:  https://www.patreon.com/bePatron?u=48464594

	Follow on YouTube and Twitter for updates:
	https://www.youtube.com/c/FoozleCC
	http://twitter.com/FoozleCC